#include "main.h"

const color_t COLOR_RED = { 236, 100, 75 };
const color_t COLOR_GREEN = { 135, 211, 124 };
const color_t COLOR_BLACK = { 52, 73, 94 };
const color_t COLOR_BACKGROUND = { 0, 38, 152 };
const color_t COLOR_BROWN = {138, 61, 0};
const color_t COLOR_SOIL = {110, 156, 0};
const color_t COLOR_YELLOW = {255, 206, 0};
const color_t COLOR_WATER = {0, 126, 255};
const color_t COLOR_ORANGE = {255, 92, 8};
const color_t COLOR_PURPLE = {126, 38, 126};
const color_t COLOR_RED2 = {213, 0, 37};
const color_t COLOR_GREEN2 = {0, 116, 0};
const color_t COLOR_POR = {56,0,0};
const color_t COLOR_MAG = {155,15,0};
const color_t COLOR_BG2 = {37,185,255};
const color_t COLOR_MTN = {188,72,14};
